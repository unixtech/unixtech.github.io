Tipue Search
------------

Tipue Search is a site search engine jQuery plugin. Tipue Search only needs a browser that supports jQuery. It doesn't need MySQL, PHP or similar. In Static mode it doesn't even need a web server.

To get started, see <http://www.tipue.com/search/>. There's a demo at <http://www.tipue.com/search/demos/static/>.

Documentation
-------------

There's full documentation at <http://www.tipue.com/search/docs/>.

Copyright and license
---------------------

Tipue Search Copyright (c) 2015 Tipue, under the The MIT License.



